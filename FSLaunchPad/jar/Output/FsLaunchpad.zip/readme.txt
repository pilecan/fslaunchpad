FSLaunchpad Version 1.0
May 2015
by Pierre Legault

Thanks for having download FSLaunchPad!
If your FSX is slow to start because you have a lot of sceneries, FsLaunchpad (FSL) is for you.
FSL allows to Select your Sceneries, Load your Addons and Launch FSX in same time.

Visit fslauncher.com you will find videos on Youtube and more information about FsLaunchpad.

[Description]

With FSL loading FSX and selected sceneries will be up to 5 times faster than if FSX loads all your scenes. FSL is a software that can manage your scenes easily. Add, edit, delete and even move your scenes in a different directory.

[Features]

- Allows to select rapidly and easily the sceneries that you needs. 
- Allows to select your Addons and Launch them with FSX (Active Sky Next, Aerosoft addons, Calculators, FMS, Excel Sheets, FuelPlanners, etc.)
- Add, Edit and  Reorganize your Sceneries easily and quickly.
- Move your Sceneries into another Folder without modify Scenery.CFG. FSL will do this for you!
- Retrieve your Sceneries Folder and Open it with One Click! 
- Select Sceneries Required to avoid to select them each time you create a set of them.
- Googlize your Sceneries on Google Search and Map.
- Google Earth Airport Information (Altitude, Runways #, Lenght(feet/meters), ILS,  Course, Type, etc).
- And More!


[FAQ} 

Please visit fslauncher.com

[Installation]

- Windows 7/8 OS
- Ensure Flight Simulator X is installed
- Ensure Java 1.7 is installed  
- Unzip FSLaunchPad.zip 
- Run setup.exe program with administration right.

[Uninstal]

- Run {group}/FSLaunchPad/uninstall.exe

[Disclaimer]

These files are used at your own risk. There is absolutely NO warranty or guarantee of any kind, expressed or implied, for any problems arising from the use of these files. This includes, but is not limited to, any hardware and/or software problems. All use of these textures and its related files is at the user�s own risk.

A copy of scenery.cfg is create first time you launch FSLaunchPad  (C:\ProgramData\Microsoft\FSX\Scenery_original_before_FSL.CFG)

[Distribution]

FSLaunchPad is released as FREEWARE. DO NOT UPLOAD anywhere without my permission. These files may not be sold or included on a CD without prior agreement. The use of these files is at your own risk, the author cannot be held responsible. 

This is FREEWARE. These files are strictly for your own personal, non-commercial use.  Any redistribution, repackaging or reselling of these files in any form is expressly prohibited without the permission of the author.


Pierre Legault
fslauncher@gmail.com



